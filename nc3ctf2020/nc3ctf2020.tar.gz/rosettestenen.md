# Rosettestenen
Have a direct word to word translation schema:
Quisque vel risus   non neque aliquet auctor nec id  neqte In  eleifend
gammel  }   flasker er  nc3   sådan   vand   set nye i     det {


neque eleifend In non aliquet nec Quisque auctor neqte id risus vel
translation schema ->
nc3{detersådansetgammelvandinyeflasker}
