# Hallo, hallo, er der nogen?
. -. -.. . .-.. .. --. ..--.- .--- ..- .-.. ..--- ----- ..--- -----
morse ->
ENDELIG_JUL2020
flag ->
nc3{ENDELIG_JUL2020}
