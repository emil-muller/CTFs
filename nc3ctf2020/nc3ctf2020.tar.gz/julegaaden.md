# Julegåden 0
Have files:
```
-rw-r--r-- 1 kali kali     404 Nov 23 12:08  0.7z
-rw-r--r-- 1 kali kali  122332 Nov 23 12:08  1.7z
-rw-r--r-- 1 kali kali    5508 Nov 23 12:09  2.7z
-rw-r--r-- 1 kali kali 2368158 Nov 23 12:09  3.7z
-rw-r--r-- 1 kali kali    9135 Nov 25 07:59  4.7z
-rw-r--r-- 1 kali kali     561 Nov 24 06:08  Intro.txt
-rw-r--r-- 1 kali kali      53 Nov 20 12:00 'K0dne 71l 0.txt'
```
`K0dne 71l 0.txt` contains:
Koden er: 2020NissejulBareDenbedste


